//
//  VOProcesso.h
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 29/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface VOProcesso : NSObject {
	NSString *nomeArquivo;
	NSString *titulo;
	NSMutableDictionary *conteudo;
	NSMutableDictionary *secoes;
	
}
@property (nonatomic,retain) NSString *nomeArquivo;
@property (nonatomic,retain) NSString *titulo;
@property (nonatomic,retain) NSMutableDictionary *conteudo;
@property (nonatomic,retain) NSMutableDictionary *secoes;

- (NSMutableArray *) listaDeSecoes;
- (NSString *) textoDaSecao: (NSInteger) numSecao;

@end
