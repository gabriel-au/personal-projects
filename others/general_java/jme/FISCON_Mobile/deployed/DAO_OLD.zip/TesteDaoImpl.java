package br.com.primems.visitamais.dao;

import java.util.Collection;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class TesteDaoImpl extends HibernateDaoSupport implements TesteDao {
	    public Collection testar() {
	    	List l = getHibernateTemplate().find("from Office");
	    	System.out.println(new java.util.Date() + "\n\n\n\n\n\n\n"+l);
	    	return l;
	    }
}
