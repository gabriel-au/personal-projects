/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.primems.visitamais.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

/**
 *
 * @author Eduardo
 */
public class HibernateUtil {

    private static SessionFactory sessionFactory;
    private static Session session;
    

    static {
        sessionFactory = new AnnotationConfiguration().configure("/hibernate.cfg.xml").buildSessionFactory();
// obs o arquivo hibernate.cfg.xml deve estar na pasta src, o hibernate procura ela la dentro
// caso queira ficar em outro lugar deve mudar aqui: new Configuration().configure("nome do pacote onde está o //arquivo").buildSessionFactory();
    }

    public static Session getCurrentSession() {
        if (session == null || !session.isOpen() || !session.isConnected()) {
            session = ((SessionFactory) sessionFactory).openSession();
        }
        return session;
    }

    public static void closeSession() {
        session.close();
    }
}
