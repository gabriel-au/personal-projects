package br.com.primems.visitamais.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Expression;

import br.com.primems.visitamais.to.Source;
import br.com.primems.visitamais.to.User;

public class SourceDao extends GenericoDao {

	public List<Source> pesquisarFontes(User user) {
		Query q = s.createQuery("from Source s left join fetch s.company c "
				+ "where c.id = :id");
		q.setInteger("id", user.getCompany().getId());
		List<Source> list = q.list();
		fechaSessao();
		return list;
	}
}
