//
//  IndiceProcessoViewController.m
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 30/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "IndiceProcessoViewController.h"
#import "IndiceViewController.h";
#import "DetalhaProcessoViewController.h"

@implementation IndiceProcessoViewController
@synthesize indiceVc,
processos,
lista,
detalheVc;


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {	
	
	//  CHAMA PROXIMA VIEW
	self.detalheVc = [[[DetalhaProcessoViewController alloc]
						initWithNibName:@"DetalhaProcessoView" bundle:nil] autorelease];
	[self.navigationController pushViewController:self.detalheVc animated: YES];
	
	self.detalheVc.processo = [self.processos objectAtIndex: indexPath.row];
	
	self.detalheVc.navigationItem.title = @"Processo";
	self.detalheVc.tituloProcesso = [self.lista objectAtIndex: indexPath.row];
	
}
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}
- (void) viewDidAppear:(BOOL)animated {
	[super viewDidAppear: YES];
}

- (void)dealloc {
	[indiceVc release];
	[detalheVc release];
	[lista release];
	[processos release];
    [super dealloc];
}


- (NSInteger) tableView : (UITableView *) tableView numberOfRowsInSection : (NSInteger) section {
	self.lista = [ProcessaArquivo listaDeProcessosString: self.processos];
	return [lista count];
}

- (UITableViewCell *) tableView : (UITableView *) tableView cellForRowAtIndexPath : (NSIndexPath *) indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [self CreateMultilinesCell:CellIdentifier];
    }
	cell.textLabel.text = [self.lista objectAtIndex:indexPath.row];

	return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// MAIS DE UMA LINHA

#define CONST_Cell_height 44.0f
#define CONST_Cell_width 270.0f

#define CONST_textLabelFontSize     17
#define CONST_detailLabelFontSize   15

static UIFont *titleFont;

- (UIFont*) TitleFont;
{
	if (!titleFont) titleFont = [UIFont boldSystemFontOfSize:CONST_textLabelFontSize];
	return titleFont;
}
/*
- (UIFont*) SubFont;
{
	if (!subFont) subFont = [UIFont systemFontOfSize:CONST_detailLabelFontSize];
	return subFont;
}
*/

- (UITableViewCell*) CreateMultilinesCell :(NSString*)cellIdentifier
{
	UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle 
													reuseIdentifier:cellIdentifier] autorelease];
	
	cell.textLabel.numberOfLines = 0;
	cell.textLabel.font = [self TitleFont];
	
	cell.detailTextLabel.numberOfLines = 0;
	//cell.detailTextLabel.font = [self SubFont];
	
	return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSString *title = [self.lista objectAtIndex:indexPath.row];
//	NSString *subtitle = [subtitles objectAtIndex:indexPath.row];
	
	int height = 20 + [self heightOfCellWithTitle:title];
	//NSLog(@"HEIGHT: %d\n %d",[self heightOfCellWithTitle:title],height);
	return (height < CONST_Cell_height ? CONST_Cell_height : height);
}

- (int) heightOfCellWithTitle :(NSString*)titleText 
				//   andSubtitle:(NSString*)subtitleText
{
	CGSize titleSize = {0, 0};
	//CGSize subtitleSize = {0, 0};
	
	if (titleText && ![titleText isEqualToString:@""]) 
		titleSize = [titleText sizeWithFont:[self TitleFont] 
						  constrainedToSize:CGSizeMake(CONST_Cell_width, 4000) 
							  lineBreakMode:UILineBreakModeWordWrap];
	
	/*if (subtitleText && ![subtitleText isEqualToString:@""]) 
		subtitleSize = [subtitleText sizeWithFont:[self SubFont] 
								constrainedToSize:CGSizeMake(CONST_Cell_width, 4000) 
									lineBreakMode:UILineBreakModeWordWrap];
	*/
	//NSLog(@"H: %d",titleSize.height);
	return titleSize.height;
}
- (void)didReceiveMemoryWarning {
	NSLog(@"Aviso de memoria no INDICE");
    [super didReceiveMemoryWarning];
}
/*
-(void) viewDidDisappear:(BOOL)animated {
	NSLog(@"release processos");
	for (VOProcesso *vo in processos) {
		[vo release];
	}
	[processos release];
}*/




@end
