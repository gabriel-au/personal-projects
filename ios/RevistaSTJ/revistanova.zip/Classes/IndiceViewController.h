//
//  IndiceViewController.h
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 26/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FileUtil.h"
#import "ProcessaArquivo.h"
#import "IndiceProcessoViewController.h"

@interface IndiceViewController : UIViewController < UIPickerViewDelegate, UIPickerViewDataSource, NSFetchedResultsControllerDelegate> {
	IBOutlet UITableView *tvTabela;
	IBOutlet UITabBarController *tabControl;
	IBOutlet UINavigationBar *nav;
	IBOutlet UINavigationController *navControl;
	NSMutableArray *listaTabela;
	IBOutlet IndiceProcessoViewController *processoVc;
	UIActivityIndicatorView *downloadIndicator;
	
	NSInteger indexSel;
	IBOutlet UIButton *botao;

	
@private
	NSFetchedResultsController *fetchedResultsController;
	NSManagedObjectContext *managedObjectContext;
}

@property (nonatomic, retain) IBOutlet UIButton *botao;
@property (nonatomic) NSInteger indexSel;
@property (nonatomic, retain) UIActivityIndicatorView *downloadIndicator;
@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;
@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;
@property (nonatomic,retain) NSMutableArray *listaTabela;
@property (nonatomic,retain) IBOutlet UITableView *tvTabela;
@property (nonatomic,retain) IBOutlet UINavigationBar *nav;
@property (nonatomic,retain) IBOutlet UITabBarController *tabControl;
@property (nonatomic,retain) IBOutlet IndiceProcessoViewController *processoVc;
@property (nonatomic,retain) IBOutlet UINavigationController *navControl;

- (IBAction) cliqueBotao : (id) sender ;
@end

