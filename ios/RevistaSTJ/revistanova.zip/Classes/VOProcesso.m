//
//  VOProcesso.m
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 29/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "VOProcesso.h"


@implementation VOProcesso
@synthesize secoes;
@synthesize titulo;
@synthesize conteudo,
nomeArquivo;

-(id)init {
    if (self = [super init]) {
		self.conteudo = [[NSMutableDictionary alloc] init];
		self.secoes = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (NSMutableArray *) listaDeSecoes {
	NSMutableArray *retorno = [[NSMutableArray alloc] init];
	for (NSInteger i = 0; i < [self.secoes count]; i++) {
		[retorno addObject: [self.secoes objectForKey: [NSString stringWithFormat: @"%d",i]]];
	}
	return retorno;
}
- (NSString *) textoDaSecao: (NSInteger) numSecao {
	return [self.conteudo objectForKey: [NSString stringWithFormat: @"%d",numSecao]];
}

- (void) dealloc {
	NSLog(@"DEALLOC VO");
	[secoes release];
	[conteudo release];
	[titulo release];
	
	[super dealloc];
}
@end
