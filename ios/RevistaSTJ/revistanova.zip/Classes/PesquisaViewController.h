//
//  PesquisaViewController.h
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 29/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ResultadoTableViewController;
@interface PesquisaViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource, UISearchBarDelegate> {
	IBOutlet UIPickerView *combo;
	NSString *parametro;
	NSMutableArray *listaCombo;
	NSMutableArray *listaProcessos;
	NSInteger indexSel;
	
	ResultadoTableViewController *resultVc;
}
@property (nonatomic,retain) ResultadoTableViewController *resultVc;
@property (nonatomic,retain) NSString *parametro;
@property (nonatomic) NSInteger indexSel;
@property (nonatomic,retain) NSMutableArray *listaCombo;
@property (nonatomic,retain) IBOutlet UIPickerView *combo;

@property (nonatomic, retain) NSMutableArray *listaProcessos;
@end
