//
//  ConteudoViewController.h
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 26/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VOProcesso.h"


@interface ConteudoViewController : UIViewController <UITextViewDelegate> {
	IBOutlet UITextView *txtView;
	IBOutlet UINavigationBar *navBar;
	IBOutlet UITextField *txtPagina;
	
	NSRange range;
	NSString *conteudo;
	
	VOProcesso *processo;
	NSInteger index;
}

@property (nonatomic, retain)	IBOutlet UITextField *txtPagina;
@property (nonatomic) NSRange range;
@property (nonatomic,retain) NSString *conteudo;
@property (nonatomic,retain) IBOutlet UITextView *txtView;
@property (nonatomic,retain) IBOutlet UINavigationBar *navBar;
@property (nonatomic,retain) VOProcesso *processo;
@property (nonatomic) NSInteger index;

- (IBAction) botaoAumentaFonte : (id) sender;
- (IBAction) botaoDiminuiFonte : (id) sender;

- (IBAction) botaoProximoTopico : (id) sender;
- (IBAction) botaoTopicoAnterior : (id) sender;

- (void) mudaTopico;

@end
