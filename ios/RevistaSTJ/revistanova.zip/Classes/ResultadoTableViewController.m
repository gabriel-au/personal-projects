//
//  ResultadoTableViewController.m
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 09/04/10.
//  Copyright 2010 primetecnologia. All rights reserved.
//

#import "ResultadoTableViewController.h"
#import "VOResultado.h"
#import "StringExtras.h"
#import "DetalhaProcessoViewController.h"
#import "ConteudoViewController.h"

@implementation ResultadoTableViewController
@synthesize listaResultados,
sectionList,
dicionarioTabela,
detalhaVc,
conteudoVc;

/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    if (self = [super initWithStyle:style]) {
    }
    return self;
}
*/

/*
- (void)viewDidLoad {
    [super viewDidLoad];


}
*/
/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	NSString *sectionSel = [self.sectionList objectAtIndex: indexPath.section];
	NSMutableArray *resultados = [dicionarioTabela objectForKey: sectionSel];
	VOResultado *vo = [resultados objectAtIndex: indexPath.row];
	//NSString *conteudo = [vo.processo.conteudo objectForKey: vo.secao];
	//NSString *titulo  = [vo.processo.secoes objectForKey: vo.secao];
	self.detalhaVc = [[DetalhaProcessoViewController alloc] initWithNibName: @"DetalhaProcessoView" 
						bundle:nil];
	self.detalhaVc.processo = vo.processo;
	self.detalhaVc.tituloProcesso = vo.processo.titulo;
	self.detalhaVc.resultado = vo;
	[self.navigationController pushViewController: self.detalhaVc animated:YES];

	


	
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


- (void)dealloc {
    [super dealloc];
}

//

#define CONST_Cell_height 44.0f
#define CONST_Cell_width 270.0f

#define CONST_textLabelFontSize     17
#define CONST_detailLabelFontSize   15

static UIFont *subFont;
static UIFont *titleFont;

- (UIFont*) TitleFont;
{
	if (!titleFont) titleFont = [UIFont boldSystemFontOfSize:CONST_textLabelFontSize];
	return titleFont;
}

- (UIFont*) SubFont;
{
	if (!subFont) subFont = [UIFont systemFontOfSize:CONST_detailLabelFontSize];
	return subFont;
}

- (UITableViewCell*) CreateMultilinesCell :(NSString*)cellIdentifier
{
	UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle 
													reuseIdentifier:cellIdentifier] autorelease];
	
	cell.textLabel.numberOfLines = 0;
	cell.textLabel.font = [self TitleFont];
	
	cell.detailTextLabel.numberOfLines = 0;
	cell.detailTextLabel.font = [self SubFont];
	
	return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [self.sectionList count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	NSMutableArray *a = [self.dicionarioTabela objectForKey: [self.sectionList objectAtIndex: section]];
	return [a count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView 
		 cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [self CreateMultilinesCell:CellIdentifier];
    }
	
	NSMutableArray *vosDaSecao = [self.dicionarioTabela objectForKey: [self.sectionList objectAtIndex: indexPath.section]];
	VOResultado *vo = [vosDaSecao objectAtIndex: indexPath.row];
    //VOResultado *vo = [self.listaResultados objectAtIndex: indexPath.row];
	
	NSString *texto = [[vo.processo.conteudo objectForKey:vo.secao] stringWithoutLineBreak];
	
	NSRange r;
	NSInteger tam=40;
	r.location = vo.range.location;
	r.length = vo.range.length +tam;
    if (r.location < 1) {
		r.location = 1;
		r.length = tam*2;
	}
	if (r.length + r.location >= texto.length) {
		r.length = (texto.length - r.location);
	}
	NSString *title = [vo.processo.secoes objectForKey: vo.secao];
	NSString *subtitle = [NSString stringWithFormat: @"[...] %@ [...]", [texto substringWithRange:r]];
	cell.textLabel.text = title;
	cell.detailTextLabel.text = subtitle ;
	 
	//cell.textLabel.text = @"blablabla";
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSMutableArray *vosDaSecao = [self.dicionarioTabela objectForKey: [self.sectionList objectAtIndex: indexPath.section]];
	VOResultado *vo = [vosDaSecao objectAtIndex: indexPath.row];
    //VOResultado *vo = [self.listaResultados objectAtIndex: indexPath.row];
	
	NSString *texto = [[vo.processo.conteudo objectForKey:vo.secao] stringWithoutLineBreak];
	
	NSRange r;
	NSInteger tam=40;
	r.location = vo.range.location;
	r.length = vo.range.length +tam;
    if (r.location < 1) {
		r.location = 1;
		r.length = tam*2;
	}
	if (r.length + r.location >= texto.length) {
		r.length = (texto.length - r.location);
	}
	NSString *title = [vo.processo.secoes objectForKey: vo.secao];
	NSString *subtitle = [NSString stringWithFormat: @"[...] %@ [...]", [texto substringWithRange:r]];
	

	int height = 10 + [self heightOfCellWithTitle:title andSubtitle:subtitle];
	return (height < CONST_Cell_height ? CONST_Cell_height : height);
}

- (int) heightOfCellWithTitle :(NSString*)titleText 
				   andSubtitle:(NSString*)subtitleText
{
	CGSize titleSize = {0, 0};
	CGSize subtitleSize = {0, 0};
	
	if (titleText && ![titleText isEqualToString:@""]) 
		titleSize = [titleText sizeWithFont:[self TitleFont] 
						  constrainedToSize:CGSizeMake(CONST_Cell_width, 4000) 
							  lineBreakMode:UILineBreakModeWordWrap];
	
	if (subtitleText && ![subtitleText isEqualToString:@""]) 
		subtitleSize = [subtitleText sizeWithFont:[self SubFont] 
								constrainedToSize:CGSizeMake(CONST_Cell_width, 4000) 
									lineBreakMode:UILineBreakModeWordWrap];
	
	return titleSize.height + subtitleSize.height;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	
	return [sectionList objectAtIndex: section];
}

@end

