//
//  Busca.m
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 06/04/10.
//  Copyright 2010 primetecnologia. All rights reserved.
//

#import "Busca.h"
#import "VOResultado.h"

@implementation Busca
@synthesize listaProcessos,
listaResultados,
listaRange;

- (id) initWithArray : (NSMutableArray *) processos {
	if (self = [super init]) {
		self.listaProcessos = processos;
		self.listaResultados = [[NSMutableArray alloc] init];
		[self.listaResultados autorelease];
		[self.listaProcessos autorelease];
	}
	return self; 
}

- (void) buscarTexto : (NSString *) texto {
	for (VOProcesso *vo in self.listaProcessos) {
		[self buscarTexto:texto noProcesso:vo];
	} 
}

- (void) buscarTexto : (NSString *) texto noProcesso: (VOProcesso *) vo {
	NSEnumerator *eConteudo = [vo.conteudo keyEnumerator];
	NSString *keyConteudo;

	while (keyConteudo = [eConteudo nextObject]) {
		NSString *aConteudo = [vo.conteudo objectForKey:keyConteudo];
		NSRange rangeConteudo = [aConteudo rangeOfString: texto options:NSCaseInsensitiveSearch];
		if (rangeConteudo.location != NSNotFound) {
			VOResultado *res = [[VOResultado alloc] init];
			[res autorelease];
			res.range = rangeConteudo;
			res.processo = vo;
			res.secao = keyConteudo;
			[self.listaResultados addObject: res];

		} else {
		}
	}
}
@end
