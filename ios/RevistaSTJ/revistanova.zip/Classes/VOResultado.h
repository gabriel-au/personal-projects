//
//  VOResultado.h
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 08/04/10.
//  Copyright 2010 primetecnologia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VOProcesso.h"

@interface VOResultado : NSObject {
	NSRange range;
	VOProcesso *processo;
	NSString *arquivo;
	NSString *secao;
}

@property (nonatomic) NSRange range;
@property (nonatomic,retain) VOProcesso *processo;
@property (nonatomic,retain) NSString *arquivo;
@property (nonatomic,retain) NSString *secao;
@end
