package br.com.primems.visitamais.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Expression;

import br.com.primems.visitamais.to.User;

public class UserDao extends GenericoDao {

	public User autenticarUsuario(User user) {
		Criteria c = s.createCriteria(User.class);
		c.add(Expression.like("login", user.getLogin()));
		c.add(Expression.like("pass", user.getPass()));
		user = (User) c.uniqueResult();
		return user;
	}

	public List<User> pesquisarUsuarios() {
		Query query = s.getNamedQuery("User.findAll");
		List<User> list = query.list();
		fechaSessao();
		return list;
	}

	public List<User> pesquisarGerentes() {
		Query q = s.createQuery("from User u" +
				" left join fetch u.rule r where r.id = :id");
		q.setInteger("id", 3);
		List<User> list  = q.list();
		fechaSessao();
		return list;
	}
	
	public List<User> pesquisarSupervisores(){
		Query q = s.createQuery("from User u" +
				" left join fetch u.rule r where r.id = :id");
		q.setInteger("id", 4);
		List<User> list = q.list();
		fechaSessao();
		return list;
	}
}
