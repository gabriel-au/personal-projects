package br.com.primems.visitamais.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Expression;

import br.com.primems.visitamais.to.Team;
import br.com.primems.visitamais.to.User;

public class EquipeDao extends GenericoDao{

	public List<Team> recuperarEquipes(User user){
		Query q = s.createQuery("from Team t " +
				"left join fetch t.office o " +
				"where o.id= :id");
		q.setInteger("id", user.getOffice().getId());
		List<Team> list = q.list();
		fechaSessao();
		return list;
	}
	
}
