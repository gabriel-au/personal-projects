package br.com.primems.visitamais.dao;

import java.util.List;

import org.hibernate.Query;

import br.com.primems.visitamais.to.Rule;

public class RoleDao extends GenericoDao {

	public List<Rule> pesquisarPapeis(){
		Query q = s.getNamedQuery("Rule.findAll");
		List<Rule> list = q.list();
		fechaSessao();
		return list;
	}
	
}
