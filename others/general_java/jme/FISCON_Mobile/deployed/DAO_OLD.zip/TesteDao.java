package br.com.primems.visitamais.dao;

import java.util.Collection;

public interface TesteDao {
	public Collection testar();
}
