/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.primems.visitamais.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.Transaction;

import br.com.primems.visitamais.exceptions.BancoDadosException;

import com.sun.org.apache.xml.internal.security.Init;

public class GenericoDao {

	Session s = null;
	Transaction t = null;

	public GenericoDao() {
		s = HibernateUtil.getCurrentSession();
		t = s.beginTransaction();
	}

	public void abrirSessao() {
		s = HibernateUtil.getCurrentSession();
	}

	public void fechaSessao() {
		HibernateUtil.closeSession();
	}

	public void salvarOuAlterar(Serializable bean) {
		abrirSessao();
		s.saveOrUpdate(bean);
		t.commit();
		fechaSessao();
	}

	public void salvarOuAlterarNaTransacao(Serializable bean) {
		s.saveOrUpdate(bean);
	}

	public void excluir(Object o) throws BancoDadosException {
		try {
			s.delete(o);
			t.commit();
			fechaSessao();
		} catch (Exception e) {
			e.printStackTrace();
			throw new BancoDadosException();
		}
	}
}
