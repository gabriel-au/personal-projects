//
//  ProcessaArquivo.m
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 29/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ProcessaArquivo.h"
#import "VOProcesso.h"
#import "StringExtras.h"
#import "IndiceViewController.h"
#import "PesquisaViewController.h"
#import "Busca.h"
#import "ResultadoTableViewController.h"
#import "VOResultado.h";

@implementation ProcessaArquivo
@synthesize stream,
voIncompleto,
stringIncompleta,
processos,
numSecao,
vi,
titulo,
busca,
pes;

- (id) init {
	if (self = [super init]) {
		self.processos = [[NSMutableArray alloc] init];
	}
	return self;
}
+ (NSMutableArray *) processa : (NSArray *) s {
	NSMutableArray *sm = [NSMutableArray arrayWithArray:s];
	
	//NSEnumerator *e = [sm objectEnumerator];
	//NSString *gravando = @"";
	NSMutableArray *processos = [[NSMutableArray alloc] init];
	VOProcesso *processo = [[VOProcesso alloc] init];
	NSInteger numSec=0;
	NSInteger contador = 0;
	NSInteger max = [sm count];
	BOOL continua = YES;
	while (continua == YES) {
		contador++;
		NSString *l;
		l = [sm objectAtIndex:0];
		if (contador == max-1) {
			continua = NO;
		}
		BOOL secaoValida = NO;

		NSString *ltrim = [l trimWhiteSpaces];
		// SE FOREM TODAS AS LETRAS MAIUSCULAS (PROCESSO OU SEÇÃO)
		if ([[l uppercaseString] isEqualToString:l] 
			&& [l containsString: @"(...)"] == NO
			&& [l containsString: @"[...]"] == NO
			&& [ltrim isEqualToString: @"\r"] == NO
			&& [ltrim isEqualToString: @""] == NO
			) {
			// Regex para reconhecer linhas referentes a um novo processo Ex: 'blblabla bla bla (1234/1231231-1)'
			NSString *regex = @".*[(][0-9]{4}[/][0-9]{7}[-][0-9]{1}[)].*";
			NSPredicate *regextest = [NSPredicate
									  predicateWithFormat:@"SELF MATCHES %@", regex];
			
			// SE FOR UM NOVO PROCESSO
			if ([regextest evaluateWithObject: l] == YES) {
				secaoValida = YES;
				// CRIA UM NOVO OBJETO
				processo = [[VOProcesso alloc] init];
				[processos addObject: processo];
				processo.titulo = l;
				//NSLog(@"%@",l);
				numSec=0;
				[processo.secoes setObject: @"DESCRIÇÃO" forKey: @"0"];
				[processo.conteudo setObject: l forKey: @"0"];
			} 
			// SE FOR UMA NOVA SEÇÃO
			else //if (ltrim.length < 15)
			{
				secaoValida = YES;
				numSec++;
	
				[processo.secoes setObject: ltrim forKey: [NSString stringWithFormat: @"%d",numSec]];
				[processo.conteudo setObject: ltrim forKey: [NSString stringWithFormat: @"%d",numSec]];
			} 
			[regex release];
		}  
		// CASO SEJA TEXTO NORMAL
		//NSLog(@"%@",l);
		if (secaoValida == NO) {
			NSString *numString = [NSString stringWithFormat: @"%d",numSec];
			NSString *tudo = [processo.conteudo objectForKey: numString];
			if (tudo == nil) {
				tudo = @"";
			}
			if ([tudo length] < 300) {
				tudo = [ tudo stringByAppendingString: @"\n"];
				[processo.conteudo setObject: [tudo stringByAppendingString: l] forKey: numString];
			}
		}
		[sm removeObjectAtIndex:0];
	}
	
	return processos;
}


+ (NSMutableArray *) listaDeProcessosString : (NSMutableArray *) processos {
	NSMutableArray *retorno = [[NSMutableArray alloc] init];
	for (VOProcesso *vo in processos) {
		[retorno addObject: vo.titulo];
	}
	return retorno;
}
+ (void) logArray : (NSMutableArray *) array {
	for (NSString *s in array) {
		NSLog (@"%@", s);
	}
}

- (void) processaArquivo:(NSString *)path {
	// iStream is NSInputStream instance variable
	self.stream = [[NSInputStream alloc] initWithFileAtPath:path];
	[self.stream setDelegate:self];
	[self.stream scheduleInRunLoop:[NSRunLoop currentRunLoop]
						   forMode:NSDefaultRunLoopMode];
	[self.stream open];
	
}

- (void)stream:(NSStream *)str handleEvent:(NSStreamEvent)eventCode
{
	switch(eventCode) {
		case NSStreamEventEndEncountered:
		{
			[str close];
			[str removeFromRunLoop:[NSRunLoop currentRunLoop]
						   forMode:NSDefaultRunLoopMode];
			[str release];
			str = nil;
			break;
		}
		case NSStreamEventHasBytesAvailable:
		{
			uint8_t buf[10240];
			unsigned int len = 0;
			len = [(NSInputStream *)stream  read:buf maxLength:sizeof(buf)];
			if(len != 0) {
				NSString* s = [[NSString alloc] initWithBytes:buf length:len encoding:NSUTF8StringEncoding];	 
				NSArray *sa = [s componentsSeparatedByString: @"\n"];
			    [self processaBuffer: sa];
				
			} 
			
			// FINAL DO PROCESSAMENTO
			else {
				// SE FOI CHAMADA PELO INDICE
				if (self.busca == NO) {
					//  CHAMA PROXIMA VIEW
					self.vi.processoVc = [[[IndiceProcessoViewController alloc]
										   initWithNibName:@"IndiceProcessoView" bundle:nil] autorelease];
					[self.vi.navigationController pushViewController:self.vi.processoVc animated: YES];
					
					self.vi.processoVc.navigationItem.title = self.titulo;
					self.vi.processoVc.processos = self.processos;
					[self.vi.downloadIndicator stopAnimating];
				}
				// SE FOI CHAMADA PELA PESQUISA
				else {
					// REALIZA A BUSCA
					Busca *bus = [[Busca alloc] initWithArray: self.processos ];
					[bus buscarTexto: self.pes.parametro];
					[bus autorelease];
					
					// CHAMA A VIEW DE RESULTADO
					self.pes.resultVc = [[ResultadoTableViewController alloc] initWithNibName:@"ResultadoTable" bundle:nil];
					[self.pes.resultVc.navigationItem setTitle: self.titulo];
					self.pes.resultVc.listaResultados = bus.listaResultados;
					self.pes.resultVc.sectionList = [[NSMutableArray alloc] init];
					
					NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
					for (VOResultado *res in bus.listaResultados) {
						NSMutableArray *sec = [dict objectForKey: res.processo.titulo];
						if (sec == nil) {
							sec = [[NSMutableArray alloc] init];
							[self.pes.resultVc.sectionList addObject: res.processo.titulo];
							[dict setObject: sec forKey: res.processo.titulo];
						}
						[sec addObject: res];
					}
					self.pes.resultVc.dicionarioTabela = dict;
					
					
					[self.pes.navigationController pushViewController: self.pes.resultVc animated: YES];
					//[resultView release];
				}
			}
		}
			
	}
}
- (void) processaBuffer : (NSArray *) buffer {
	NSEnumerator *e = [buffer objectEnumerator];
	
	VOProcesso *processo;
	if (self.voIncompleto == nil) {
		processo = [[VOProcesso alloc] init];
	} else {
		processo = self.voIncompleto;
	}
	
	BOOL first = YES;
	BOOL primeiraLinhaSecao = YES;
	int contador = 0;
	int total = [buffer count];
	NSString *inc=@"";
	NSString *s; // linha atual
	while (s = [e nextObject]) {
		// caso seja a primeira iteração e a string incompleta estiver preenchida.
		if (first && self.stringIncompleta != nil) {
			s = [ self.stringIncompleta stringByAppendingString: s];
			first = NO;
		}
		// caso seja o último registro do array, break
		if (contador == total -  1) {
			inc=s;
			break;
		}
		NSString *ltrim = [s trimWhiteSpaces];
		
		// SE FOREM TODAS AS LETRAS MAIUSCULAS (PROCESSO OU SEÇÃO)
		if ([[s uppercaseString] isEqualToString:s] 
			&& [s containsString: @"(...)"] == NO
			&& [s containsString: @"[...]"] == NO
			&& [ltrim isEqualToString: @"\r"] == NO
			&& [ltrim isEqualToString: @""] == NO
			) {
			
			NSString *regex = @".*[(][0-9]{4}[/][0-9]{7}[-][0-9]{1}[)].*";
			NSPredicate *regextest = [NSPredicate
									  predicateWithFormat:@"SELF MATCHES %@", regex];
			
			// SE FOR UM NOVO PROCESSO
			if ([regextest evaluateWithObject: s] == YES) {
				primeiraLinhaSecao = YES;
				// CRIA UM NOVO VO
				processo = [[VOProcesso alloc] init];
				[self.processos addObject: processo];
				processo.titulo = s;
				self.numSecao = 0;
				processo.nomeArquivo = self.titulo;
				//NSLog(@"\n\n <<<<<<<<<<<<<<<<< %@ >>>>>>>>>>>>>>>>> \n\n",s);
				[processo.secoes setObject: @"DESCRIÇÃO" forKey: @"0"];
				[processo.conteudo setObject: [[NSMutableString alloc] initWithString: @""] forKey: @"0"];
			} 
			
			// SE FOR UMA NOVA SEÇÃO
			else if (ltrim.length < 15)
			{
				primeiraLinhaSecao = YES;
				self.numSecao++;
				[processo.secoes setObject: ltrim forKey: [NSString stringWithFormat: @"%d", self.numSecao]];
				[processo.conteudo setObject: [[[NSMutableString alloc] initWithString: @""] autorelease] forKey: [NSString stringWithFormat: @"%d", self.numSecao]];
			} 
			[regex release];
			
		}
		// CASO SEJA UMA LINHA NORMAL
		else {
			NSString *numString = [NSString stringWithFormat: @"%d", self.numSecao];
			NSMutableString *tudo = [processo.conteudo objectForKey: numString];
			if (primeiraLinhaSecao == NO) {
				[tudo appendString: @"\n"];
			} else {
				primeiraLinhaSecao = NO;
			}
	
			//if (self.numSecao == 2) { 
			////	NSLog(@"\n\nARRAY %d \n\n TUDO: %@ \n\n LINHA: %@", buffer,tudo,s); 
			//}
			
			[tudo appendString: s];
		}
		contador++;
		
	}
	
	self.stringIncompleta = inc;
	self.voIncompleto = processo;
}

@end
