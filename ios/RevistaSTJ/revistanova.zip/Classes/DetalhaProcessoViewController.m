//
//  DetalhaProcessoViewController.m
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 30/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "DetalhaProcessoViewController.h"
#import "ProcessaArquivo.h";
#import "ConteudoViewController.h"
#import "VOResultado.h";

@implementation DetalhaProcessoViewController
@synthesize processo,lista,contVc,
tituloProcesso,
navItem,
resultado,
index;



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {	
	
	//  CHAMA PROXIMA VIEW
	self.contVc = [[[ConteudoViewController alloc]
					   initWithNibName:@"ConteudoView" bundle:nil] autorelease];
	[self.navigationController pushViewController:self.contVc animated: YES];
	
	self.contVc.conteudo = [self.processo.conteudo objectForKey: [NSString stringWithFormat: @"%d", indexPath.row]];
	self.contVc.navigationItem.title = [self.lista objectAtIndex: indexPath.row];
	self.contVc.processo = self.processo;
	self.contVc.index = indexPath.row;
}

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/



- (void) viewDidAppear:(BOOL)animated {

	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 500, 200)];
	[label setFont:[UIFont boldSystemFontOfSize:13.0]];
	[label setBackgroundColor:[UIColor clearColor]];
	[label setTextColor:[UIColor whiteColor]];
	[label setText: self.tituloProcesso];
	[label setNumberOfLines: 2];
	[label setTextAlignment: UITextAlignmentCenter];
	[self.navItem setTitleView:label];
	[label release];
	
	if (resultado != nil) {
		//  CHAMA PROXIMA VIEW
		self.contVc = [[[ConteudoViewController alloc]
						initWithNibName:@"ConteudoView" bundle:nil] autorelease];
		
		
		self.contVc.conteudo = [self.resultado.processo.conteudo objectForKey: self.resultado.secao];
		self.contVc.navigationItem.title = [self.resultado.processo.secoes objectForKey: self.resultado.secao];
		self.contVc.range = resultado.range;
		self.contVc.processo = self.processo;
		self.contVc.index = [self.resultado.secao integerValue];
		[self.navigationController pushViewController:self.contVc animated: YES];
		resultado = nil;
	}

}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


- (NSInteger) tableView : (UITableView *) tableView numberOfRowsInSection : (NSInteger) section {
	self.lista = [processo listaDeSecoes];
	return [lista count];
}

- (UITableViewCell *) tableView : (UITableView *) tableView cellForRowAtIndexPath : (NSIndexPath *) indexPath {
    
	UITableViewCell *cell =  [tableView dequeueReusableCellWithIdentifier:@"celula"];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle: UITableViewCellStyleDefault  reuseIdentifier: @"celula"] autorelease];			
	}
	cell.textLabel.text = [self.lista objectAtIndex:indexPath.row];
	return cell;
}
@end
