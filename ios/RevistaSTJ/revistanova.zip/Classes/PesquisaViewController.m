//
//  PesquisaViewController.m
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 29/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "PesquisaViewController.h"
#import "FileUtil.h"
#import "StringExtras.h"
#import "Busca.h"
#import "ProcessaArquivo.h"

@implementation PesquisaViewController
@synthesize combo,
listaCombo,
indexSel,
listaProcessos,
parametro,
resultVc;

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;
{
    return 1;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	self.indexSel = row;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
{
    return [listaCombo count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component;
{
    return [listaCombo objectAtIndex:row];
}

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	FileUtil *util = [[FileUtil alloc] init];
	NSString *dir = [util filePathAsString: [util directoryAsString: NSDocumentDirectory] andFileName: @"Revista"];
	NSArray *cont = [util listFilesAndFoldersInDirectory: dir];
	NSMutableArray *listaFormatada = [[NSMutableArray alloc] init];
	NSEnumerator *en = [cont objectEnumerator];
	id objeto;
	while (objeto = [en nextObject]) {
		NSString *cell = objeto;
		if ([cell containsString: @"DS_Store"]) {
			
		}else {
			cell = [cell stringByDeletingPathExtension];
			[listaFormatada addObject:cell];
		}
	}
	self.listaCombo = listaFormatada;
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}



// EVENTOS DA SEARCHBAR

// Mostra botão de cancelar ao começar a digitar e esconde ao terminar.
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
	[searchBar becomeFirstResponder];
	[searchBar setShowsCancelButton:YES animated:YES];
	
}
- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar {
	[searchBar resignFirstResponder];
	[searchBar setShowsCancelButton:NO animated:YES];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar {
	[searchBar resignFirstResponder];
	[searchBar setShowsCancelButton:NO animated:YES];
}

// CLIQUE NO BOTAO DE PESQUISA
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	NSString *s = [searchBar text];
	NSLog(@"%@",s);
	
	// pega filepath do arquivo selecionado
	NSString *sel = [self.listaCombo objectAtIndex: self.indexSel];

	FileUtil *util = [[FileUtil alloc] init];
	NSString *dir = [util filePathAsString: [util directoryAsString: NSDocumentDirectory] andFileName:@"Revista/"];
	NSString *path = [util filePathAsString: dir andFileName: [sel stringByAppendingString: @".txt"]];
	//NSArray *arr = [util fileContentAsStringArray:path];
	
	ProcessaArquivo *b = [[ProcessaArquivo alloc] init];
	b.busca = YES;
	b.pes = self;
	b.titulo = sel;
	self.parametro = s;
	[b processaArquivo: path];
	
	//self.lista = [self buscaPorNome:s];
	//[self.tabela reloadData];
}
- (void) continuaBusca {

}


@end
