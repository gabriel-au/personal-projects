//
//  Busca.h
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 06/04/10.
//  Copyright 2010 primetecnologia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VOProcesso.h"



@interface Busca : NSObject {
	NSMutableArray *listaProcessos;
	NSMutableArray *listaResultados;
	NSMutableDictionary *listaRange;

}


@property (nonatomic,retain)  NSMutableArray *listaProcessos;
@property (nonatomic,retain)  NSMutableArray *listaResultados;
@property (nonatomic,retain)  NSMutableDictionary *listaRange;


- (void) buscarTexto : (NSString *) texto;
- (void) buscarTexto : (NSString *) texto noProcesso: (VOProcesso *) vo;
@end
