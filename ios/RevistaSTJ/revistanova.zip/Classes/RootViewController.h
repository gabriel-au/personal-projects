//
//  RootViewController.h
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 01/04/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//


@interface RootViewController : UITableViewController <NSFetchedResultsControllerDelegate> {
	NSFetchedResultsController *fetchedResultsController;
	NSManagedObjectContext *managedObjectContext;
}

@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;
@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

@end
