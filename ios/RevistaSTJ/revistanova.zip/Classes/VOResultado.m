//
//  VOResultado.m
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 08/04/10.
//  Copyright 2010 primetecnologia. All rights reserved.
//

#import "VOResultado.h"


@implementation VOResultado
@synthesize range,
processo,
arquivo,
secao;



@end
