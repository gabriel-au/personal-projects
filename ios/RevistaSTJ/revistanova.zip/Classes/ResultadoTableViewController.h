//
//  ResultadoTableViewController.h
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 09/04/10.
//  Copyright 2010 primetecnologia. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetalhaProcessoViewController.h"
@class ConteudoViewController;
 
@interface ResultadoTableViewController : UITableViewController <UITableViewDelegate, UITableViewDataSource> {
	NSMutableArray *listaResultados;
	
	//NSMutableDictionary< String , NSMutableArray<VOResultado> >
	NSMutableDictionary *dicionarioTabela;
	NSMutableArray *sectionList;
	
	DetalhaProcessoViewController *detalhaVc;
	ConteudoViewController *conteudoVc;
}
@property (nonatomic,retain) ConteudoViewController *conteudoVc;
@property (nonatomic,retain) DetalhaProcessoViewController *detalhaVc;
@property (nonatomic,retain) NSMutableDictionary *dicionarioTabela;
@property (nonatomic,retain) NSMutableArray *sectionList;
@property (nonatomic,retain) NSMutableArray *listaResultados;

- (UITableViewCell*) CreateMultilinesCell :(NSString*)cellIdentifier;
- (int) heightOfCellWithTitle :(NSString*)titleText  andSubtitle:(NSString*)subtitleText;

@end
