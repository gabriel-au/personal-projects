//
//  DetalhaProcessoViewController.h
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 30/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VOProcesso.h"
#import "VOResultado.h";
@class ConteudoViewController;
@interface DetalhaProcessoViewController : UIViewController <UITableViewDataSource, UITableViewDelegate> {
	VOProcesso *processo;
	VOResultado *resultado;
	
	NSInteger index;
	NSMutableArray *lista;
	ConteudoViewController *contVc;
	NSString *tituloProcesso;
	IBOutlet UINavigationItem *navItem;

}

@property (nonatomic) NSInteger index;
@property (nonatomic,retain) VOResultado *resultado;
@property (nonatomic,retain) NSString *tituloProcesso;
@property (nonatomic,retain) VOProcesso *processo;
@property (nonatomic,retain) NSMutableArray *lista;
@property (nonatomic,retain) ConteudoViewController *contVc;
@property (nonatomic,retain) IBOutlet UINavigationItem *navItem;


@end
