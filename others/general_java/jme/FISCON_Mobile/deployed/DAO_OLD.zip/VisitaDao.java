package br.com.primems.visitamais.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Expression;

import br.com.primems.visitamais.to.Visit;



public class VisitaDao extends GenericoDao{

	public List<Visit> pesquisarVisitas(){
		Query q  = s.getNamedQuery("Visit.findAll");
		List<Visit> list = q.list();
		fechaSessao();
		return list;
	}
	
	public List<Visit> pesquisarVisitas(Visit visit){
		Criteria criteria = s.createCriteria(Visit.class);
		criteria.add(Expression.between("visitDate", visit.getDataInicial(), visit.getDataFinal()));
		List<Visit> list = criteria.list();
		fechaSessao();
		return list;
	}
	

}
