//
//  ConteudoViewController.m
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 26/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ConteudoViewController.h"


@implementation ConteudoViewController
@synthesize navBar;
@synthesize conteudo,txtView,range,
processo, index, txtPagina;


/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {

    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}
- (void) viewWillAppear:(BOOL)animated {


}

- (void)dealloc {
    [super dealloc];
}


- (void) viewDidAppear:(BOOL)animated {
	//[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(tecladoApareceu) name:UIKeyboardDidShowNotification object:nil];
	
	[self mudaTopico];
	
	
	// TENTATIVA DE FAZER O CURSOR APARECER
	if (self.range.length != 0) {
		self.txtView.selectedRange = NSMakeRange(self.range.location, 0);
	}
	

}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
	return NO;
}

- (void) tecladoApareceu {
	[self.txtView resignFirstResponder];
}

// ACOES DA TOOLBAR

- (IBAction) botaoAumentaFonte : (id) sender {
	self.txtView.font = [UIFont fontWithName: self.txtView.font.fontName size: self.txtView.font.pointSize+3.0];
}						
- (IBAction) botaoDiminuiFonte : (id) sender {
	self.txtView.font = [UIFont fontWithName: self.txtView.font.fontName size: self.txtView.font.pointSize-3.0];
}	

- (IBAction) botaoProximoTopico : (id) sender {
	if (self.index < [self.processo.secoes count] -1) {
		self.index++;
		[self mudaTopico];
	}
}
- (IBAction) botaoTopicoAnterior : (id) sender {
	if (self.index > 0) {
		self.index--;
		[self mudaTopico];
	}
	
}

- (void) mudaTopico {

	// PEGA A FONTE DA ULTIMA TXTVIEW E REMOVE DA VIEW
	CGFloat fl;
	if (self.txtView != nil) {
	  fl = self.txtView.font.pointSize;
			[self.txtView removeFromSuperview];
	} else {
		fl =17;
	}

	// CRIA UMA NOVA TXTVIEW E ADD NA VIEW
	self.txtView = [[[UITextView alloc] initWithFrame: CGRectMake(0, 0, 320, 325)] autorelease] ;
	self.txtView.delegate = self;
	self.txtView.font = [UIFont fontWithName: self.txtView.font.fontName size: fl];
	self.txtView.editable = YES;
	[self.view addSubview: self.txtView];
	
	// SETA O CONTEUDO NA TXTVIEW E O TITULO
	self.conteudo = [self.processo.conteudo objectForKey: [NSString stringWithFormat: @"%d",self.index]];
	self.txtView.text = self.conteudo;
	self.navigationItem.title = [self.processo.secoes objectForKey: [NSString stringWithFormat: @"%d",self.index]];
	
	// MOSTRAR PAGINAS (ex 04/05)
	NSString *at,*tt;
	if (self.index+1 < 10) {
		at = [@"0" stringByAppendingFormat: @"%d", self.index+1];
	} else {
		at= [NSString stringWithFormat: @"%d", self.index+1];
	}
	NSInteger tot = [self.processo.secoes count];
	if (tot < 10) {
		tt = [@"0" stringByAppendingFormat: @"%d", tot];
	} else {
		tt= [NSString stringWithFormat: @"%d", tot];
	}
	
	self.txtPagina.text = [at stringByAppendingFormat: @"/%@",tt];



}

@end
