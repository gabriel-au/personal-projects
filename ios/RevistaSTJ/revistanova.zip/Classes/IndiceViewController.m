//
//  IndiceViewController.m
//  RevistaSTJ
//
//  Created by Eduardo Carminati C Ribeiro on 26/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "IndiceViewController.h"
#import "FileUtil.h"
#import "ProcessaArquivo.h"
#import "IndiceProcessoViewController.h"
#import "StringExtras.h"


@implementation IndiceViewController
@synthesize tvTabela;
@synthesize listaTabela;
@synthesize tabControl,nav,processoVc,navControl,
downloadIndicator,
indexSel,
botao;

- (IBAction) cliqueBotao : (id) sender {
	//tableView.allowsSelection = NO;
	downloadIndicator = [[UIActivityIndicatorView alloc]initWithFrame:CGRectMake(0.0f, 0.0f, 50.0f, 50.0f)];
	[downloadIndicator setCenter:CGPointMake(160.0f,200.0f)]; 
	[downloadIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleWhiteLarge];
	[self.view addSubview:downloadIndicator]; downloadIndicator.hidden = FALSE; 
	[downloadIndicator startAnimating]; 
	[self.view bringSubviewToFront:downloadIndicator];	
	
	
	
	NSString *sel = [listaTabela objectAtIndex:self.indexSel];
	FileUtil *util = [[FileUtil alloc] init];
	NSString *dir = [util filePathAsString: [util directoryAsString: NSDocumentDirectory] andFileName:@"Revista/"];
	NSString *path = [util filePathAsString: dir andFileName: [sel stringByAppendingString: @".txt"]];
	//NSArray *arr = [util fileContentAsStringArray:path];
	
	ProcessaArquivo *b = [[ProcessaArquivo alloc] init];
	[b processaArquivo: path];
	b.vi = self;
	b.titulo = sel;
	
	/*
	 //  CHAMA PROXIMA VIEW
	 self.processoVc = [[[IndiceProcessoViewController alloc]
	 initWithNibName:@"IndiceProcessoView" bundle:nil] autorelease];
	 [self.navigationController pushViewController:self.processoVc animated: YES];
	 
	 self.processoVc.navigationItem.title = sel;
	 //self.processoVc.processos = b.processos;
	 self.processoVc.processos = [ProcessaArquivo processa: arr];
	 */
	//[tableView deselectRowAtIndexPath:indexPath animated:YES]; 
}


- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;
{
    return 1;
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	self.indexSel = row;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
{
    return [listaTabela count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component;
{
    return [listaTabela objectAtIndex:row];
}




- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{	
	

}

/*
- (IBAction) proximaView: (id) sender{
	self.processoVc = [[[IndiceProcessoViewController alloc]
					initWithNibName:@"IndiceProcessoView" bundle:nil] autorelease];
	[self.navigationController pushViewController:self.processoVc animated: YES];
}*/


- (NSInteger) tableView : (UITableView *) tableView numberOfRowsInSection : (NSInteger) section {
	return [ self.listaTabela count ];
}

- (UITableViewCell *) tableView : (UITableView *) tableView cellForRowAtIndexPath : (NSIndexPath *) indexPath {
	UITableViewCell *cell =  [tableView dequeueReusableCellWithIdentifier:@"celula"];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle: UITableViewCellStyleDefault  reuseIdentifier: @"celula"] autorelease];			
	}

	cell.textLabel.text = [listaTabela objectAtIndex:indexPath.row];
	return cell;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}

- (void)didReceiveMemoryWarning {
	NSLog(@"Aviso de memoria no INDICE");
    [super didReceiveMemoryWarning];
}
- (void) viewDidLoad {
	FileUtil *util = [[FileUtil alloc] init];
	NSString *dir = [util filePathAsString: [util directoryAsString: NSDocumentDirectory] andFileName: @"Revista"];
	NSArray *cont = [util listFilesAndFoldersInDirectory: dir];
	NSMutableArray *listaFormatada = [[NSMutableArray alloc] init];
	NSEnumerator *en = [cont objectEnumerator];
	id objeto;
	while (objeto = [en nextObject]) {
		NSString *cell = objeto;
		if ([cell containsString: @"DS_Store"]) {
			
		}else {
		cell = [cell stringByDeletingPathExtension];
		[listaFormatada addObject:cell];
		}
	}
	self.listaTabela = listaFormatada;
	// DOWNLOAD E DESCOMPACTACAO
	if (YES) {
		NSLog(@"Deletando");
		NSArray *dels = [util listFilesAndFoldersInDirectory: dir];
		for (NSString *ite in dels) {
				[util deleteFile: [util filePathAsString:dir andFileName: ite]];
		}
		NSLog(@"Baixando");
		[util saveFileFromURL: @"http://androides.com.br/Revista.zip" toDirectory: [util directoryAsString: NSDocumentDirectory] andFileName: @"down.zip"];
		NSLog(@"Baixei");
		[util unzipSavedFile];
		NSLog(@"Dezipei");
	}

}

- (void)viewDidUnload {

}

- (void)dealloc {	
    [super dealloc];
}
- (void) viewDidAppear:(BOOL)animated {
	[self.downloadIndicator stopAnimating];
		self.tvTabela.allowsSelection = YES;

}
- (void) viewWillAppear:(BOOL)animated {
	self.nav.hidden= YES;
}

- (void) viewWillDisappear:(BOOL)animated {
	self.nav.hidden = NO;
}



@end
