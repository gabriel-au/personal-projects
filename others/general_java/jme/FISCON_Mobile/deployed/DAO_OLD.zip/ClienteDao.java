package br.com.primems.visitamais.dao;

import java.util.List;

import org.hibernate.Query;

import br.com.primems.visitamais.to.Client;
import br.com.primems.visitamais.to.User;


public class ClienteDao extends GenericoDao {
	public List<Client> recuperarClientes(User user) {
		Query q = s.createQuery("from Client c left join fetch "
				+ "c.office o " + "where o.id = :id");
		q.setInteger("id", user.getOffice().getId());
		List<Client> list = q.list();
		fechaSessao();
		return list;
	}
}
